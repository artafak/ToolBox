Lancer et installer PE.Explorer_setup du dossier "version du site officiel"  (c'est la version officielle).
Une fois install�, copier le contenu du dossier "licence" dans le dossier d'install de PE Explorer.


Possibilit� d'utiliser la version portable, qui est extraite du "PE.Explorer.v1.99.R6.Full cracked (non v�rifi�)"